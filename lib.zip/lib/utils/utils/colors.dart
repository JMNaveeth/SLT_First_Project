import 'package:flutter/material.dart';

const Color mainBackgroundColor = Color(0xff343A40);
const Color suqarBackgroundColor = Color(0xff212529);
const Color mainTextColor = Color(0xffFFFFFF);
const Color subTextColor = Color(0xffD9D9D9);
const Color qrcodeiconColor1 = Color(0xff20C997);
const Color appbarColor = Color(0xff2B3136);
const Color highlightColor = Color(0xff4FC3F7);
